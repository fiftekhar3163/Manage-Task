export const Header = () => {
  return (
    <header className="header">
      <h1 className="text-center">Task Tracker Pro</h1>
    </header>
  );
};
